/**
 * @file BitWOper.h
 * @brief Header file que contém a declaração das funções de operações bitwise.
 */

int bitWiseHandle(STACK *s, char *token);
