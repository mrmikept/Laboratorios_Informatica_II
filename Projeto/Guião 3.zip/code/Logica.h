/**
 * @file Logica.h
 * @brief Header file que contém a declaração das funções de logica usadas em outros modúlos.
 */
int logicHandle(STACK *s, char *token);