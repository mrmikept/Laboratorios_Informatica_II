/**
 * @file stack.c
 * @brief Ficheiro que possui todas as funções de manuseamento da stack.
 */

#include <stdlib.h>
#include <stdio.h>
#include "stack.h"
#include "variables.h"


/**
 * @brief Função que cria uma stack.
 *
 * @param Function varValues(s) - Função para popular o array variables com os valores iniciais das váriaveis.
 * @return s - Apontador para a stack.
 */
STACK *new_Stack()
{
    STACK *s = (STACK *)malloc(sizeof(STACK));
    varValues(s);
    return s;
}

/**
 * @brief Função que faz push de um novo elemento para o topo da stack.
 *
 * Incrementa o apontador para a stack e coloca o valor da variavel elem no topo da stack.
 * @param[in] s Recebe um apontador para a stack
 * @param[in] elem Recebe um elemento a ser colocado no topo da stack.
 */
void push(STACK *s, STACK_ELEM elem)
{
    s->sp++;
    s->stack[s->sp] = elem;
}

/**
 * @brief Função que faz pop do elemento do topo da stack.
 *
 * Guarda o valor que esta no topo da stack na variavel ret e decrementa o apontador para a stack.
 * @param[in] s Recebe um apontador para a stack.
 * @return Valor da váriavel ret.
 * @param Var ret - Guarda o valor do topo da stack para depois ser retornado.
 */
STACK_ELEM pop(STACK *s)
{
    STACK_ELEM ret = s->stack[s->sp];
    s->sp--;
    return ret;
}

/**
 * @brief Função que faz print dos conteudos da stack.
 *
 * Função que faz print dos valores guardados na stack dependendo do tipo do elemento.
 * @param s
 */
void printStack(STACK *s)
{
    for (int i = 1; i <= s->sp; i++)
    {
        if (s->stack[i].t == CHAR)
        {
            printf("%c", *(char *)(s->stack[i].elem));
        }
        if (s->stack[i].t == INT)
        {
            printf("%ld", *(long *)(s->stack[i].elem));
        }
        if (s->stack[i].t == DBL)
        {
            printf("%g", *(double *)(s->stack[i].elem));
        }
        if (s->stack[i].t == STR)
        {
            printf("%s", (char *)(s->stack[i].elem));
        }
    }
    printf("\n");
}