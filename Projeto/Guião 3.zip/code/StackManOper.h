/**
 * @file StackManOper.h
 * @brief Header file que contém a declaração das funções de operações de manipulação da stack usadas em outros módulos.
 */
int stackManipHandle(STACK *s, char *token);