/**
 * @file mathOper.h
 * @brief Header file que contém a declaração das funções de operações matemáticas usadas em outros módulos.
 */

int mathHandle(STACK *s, char *token);