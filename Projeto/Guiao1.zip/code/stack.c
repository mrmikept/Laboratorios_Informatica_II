/**
 * @file stack.c
 * @brief Ficheiro que possui todas as funções de manuseamento da stack.
 */

#include <stdlib.h>
#include "stack.h"

/**
 * @brief Função que cria uma stack.
 * 
 * @return STACK* 
 */
STACK * new_Stack() {
    return (STACK *) malloc(sizeof(STACK));
}

/**
 * @brief Função que faz push de um novo elemento para o topo da stack.
 * 
 * Incrementa o apontador para a stack e coloca o valor da variavel elem no topo da stack.
 * @param[in] s Recebe um apontador para a stack
 * @param[in] elem Recebe um elemento a ser colocado no topo da stack.
 */
void push(STACK *s, int elem) {
    s->sp++;
    s->stack[s->sp] = elem;
}

/**
 * @brief Função que faz pop do elemento do topo da stack.
 * 
 * Guarda o valor que esta no topo da stack na variavel ret e decrementa o apontador para a stack.
 * @param[in] s Recebe um apontador para a stack.
 * @return Valor da váriavel ret.
 * @param Var ret - Guarda o valor do topo da stack para depois ser retornado.
 */
int pop(STACK *s) {
    int ret = s->stack[s->sp];
    s->sp--;
    return ret;
}