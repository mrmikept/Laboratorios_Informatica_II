/**
 * @brief Define um valor máximo usado para criar o tamanho do array usado para simular a stack.
 * 
 */
#define MAX_STACK 1000
/**
 * @file stack.h
 * @brief Header file que contém a declaração das funções de manuseamento da stack e da struck usada para simular a stack.
 */


/**
 * @struct STACK stack.h "stack.h"  
 * @brief Estrutura STACK, onde simula uma stack usando um array.
 * 
 * @param Array stack[MAX_STACK] - array para simular a stack.
 * @param Pointer sp - Apontador para a stack.
 */
typedef struct
{
    int stack[MAX_STACK];
    int sp;
} STACK;

STACK *new_Stack();
void push(STACK *s, int elem);
int pop(STACK *s);
