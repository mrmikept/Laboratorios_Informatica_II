/**
 * @file main.c
 * @brief Ficheiro main que contém a maior parte das funções necessárias para o funcionamento do programa.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "stack.h"

/**
 * @brief Função de adição dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' + ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da adição de x com y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x + y) - Guarda no topo da stack o resultado da soma de x e y.
 */
int add(STACK *s, char *token)
{
    if (strcmp(token, "+") == 0)
    {
        int x = pop(s);
        int y = pop(s);
        push(s, x + y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de subtração dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' - ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da subtração de x com y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor para a subtração do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor para a subtração do topo da stack com o auxilio da função pop.
 * @param function push(s, x - y) - Guarda no topo da stack o resultado da subtração de x e y.
 */
int sub(STACK *s, char *token)
{
    if (strcmp(token, "-") == 0)
    {
        int y = pop(s);
        int x = pop(s);
        push(s, x - y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de multiplicação dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' * ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da multiplicação de x por y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x * y) - Guarda no topo da stack o resultado da multiplicação de x por y.
 */
int mult(STACK *s, char *token)
{
    if (strcmp(token, "*") == 0)
    {
        int x = pop(s);
        int y = pop(s);
        push(s, x * y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de divisão(inteira) dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' / ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da divisão de x por y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x * y) - Guarda no topo da stack o resultado da divisão de x por y.
 */
int divd(STACK *s, char *token)
{
    if (strcmp(token, "/") == 0)
    {
        int y = pop(s);
        int x = pop(s);
        push(s, x / y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de decremento do valor do topo da stack
 * 
 *  É comparado o token com o caracter ' ( ',
 *  Se for igual então guarda o valor do topo da stack na variavel x, com o auxilio da função push coloca no topo da stack o resultado da decrementação de x e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x - 1) - Guarda no topo da stack o resultado da decrementação de x.
 */
int dec(STACK *s, char *token)
{
    if (strcmp(token, "(") == 0)
    {
        int x = pop(s);
        push(s, x - 1);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de incremento do valor do topo da stack
 * 
 *  É comparado o token com o caracter ' ) ',
 *  Se for igual então guarda o valor do topo da stack na variavel x, com o auxilio da função push coloca no topo da stack o resultado da incrementação de x e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x + 1) - Guarda no topo da stack o resultado da incrementação de x.
 */
int inc(STACK *s, char *token)
{
    if (strcmp(token, ")") == 0)
    {
        int x = pop(s);
        push(s, x + 1);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de operação modúlo dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' % ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação módulo de x por y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x % y) - Guarda no topo da stack o resultado da operação modulo de x por y.
 */
int modulo(STACK *s, char *token)
{
    if (strcmp(token, "%") == 0)
    {
        int y = pop(s);
        int x = pop(s);
        push(s, x % y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de exponeciação dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' # ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis expon e base, usando um ciclo calcula o resultado guardado-o na varíavel res, faz push de res para a stack e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var expon - Guarda o valor do expoente(primeiro valor do topo da stack) com o auxilio da função pop.
 * @param Var y - Guarda o valor da base(segundo valor do topo da stack) com o auxilio da função pop.
 * @param Var res - variavel que guarda o valor da exponenciação.
 * @param function push(s, res) - Guarda no topo da stack o valor de res.
 */
int expo(STACK *s, char *token)
{
    if (strcmp(token, "#") == 0)
    {
        int expon = pop(s);
        int base = pop(s);
        int res = 1;
        for (int i = 0; i < expon; i++)
        {
            res *= base;
        }
        push(s, res);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de operação e(bitwise) dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' & ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação e(bitwise) de x com y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x % y) - Guarda no topo da stack o resultado da operação e(bitwise) de x com y.
 */
int andBitW(STACK *s, char *token)
{
    if (strcmp(token, "&") == 0)
    {
        int x = pop(s);
        int y = pop(s);
        push(s, x & y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de operação ou(bitwise) dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' | ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação ou(bitwise) de x com y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x % y) - Guarda no topo da stack o resultado da operação ou(bitwise) de x com y.
 */
int orBitW(STACK *s, char *token)
{
    if (strcmp(token, "|") == 0)
    {
        int x = pop(s);
        int y = pop(s);
        push(s, x | y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de operação xor(bitwise) dos dois valores do topo da stack.
 * 
 *  É comparado o token com o caracter ' ^ ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação xor(bitwise) de x com y e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param Var y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param function push(s, x % y) - Guarda no topo da stack o resultado da operação xor(bitwise) de x com y.
 */
int xorBitW(STACK *s, char *token)
{
    if (strcmp(token, "^") == 0)
    {
        int x = pop(s);
        int y = pop(s);
        push(s, x ^ y);
        return 1;
    }
    return 0;
}

/**
 * @brief Função de operação not(bitwise) do valor no topo da stack.
 * 
 *  É comparado o token com o caracter ' ~ ',
 *  Se for igual então guarda o valor do topo da stack nas variaveis x, com o auxilio da função push coloca no topo da stack o resultado da operação not(bitwise) de x e retorna 1 à função handle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param Var x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param function push(s, ~x) - Guarda no topo da stack o resultado da operação not(bitwise) de x com y.
 */
int notBitW(STACK *s, char *token)
{
    if (strcmp(token, "~") == 0)
    {
        int x = pop(s);
        push(s, ~x);
        return 1;
    }
    return 0;
}

/**
 * @brief Função que insere valores na stack recebidos pelo input.
 * 
 * Guarda o valor do token na variavel val e faz push do número para a stack.
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * @return 1 se a função foi executada com sucesso.
 * @param Var val - Guarda o valor do numero recebido pelo input.
 * @param function push(s, x % y) - Guarda no topo da stack o resultado da operação e(bitwise) de x com y.
 */
int val(STACK *s, char *token)
{
    int val;
    sscanf(token, "%d", &val);
    push(s, val);
    return 1;
}

/**
 * @brief Função que processa o token chamando as diversas funções de operação matématica. 
 * 
 * @param[in] s Recebe um apontador para a stack. 
 * @param[in] token Recebe um token.
 * 
 */
int handle(STACK *s, char *token)
{
    int x = (add(s, token) || sub(s, token) || 
    mult(s, token) || divd(s, token) || dec(s, token) || 
    inc(s, token) || modulo(s, token) || expo(s, token) || 
    andBitW(s, token) || orBitW(s, token) || xorBitW(s, token) || 
    notBitW(s, token) || val(s, token));
    return x;
}

/**
 * @brief Função main.
 * 
 * Primeiro cria uma nova stack e depois recebe uma linha com o stdin e passa os parametros para a função handle. No fim faz print do resultado da stack.
 */
int main()
{
    STACK *s = new_Stack();
    char line[BUFSIZ];
    char token[BUFSIZ];

    if (fgets(line, BUFSIZ, stdin) != NULL)
    {
        while (sscanf(line, "%s%[^\n]", token, line) == 2)
        {
            handle(s, token);
        }
        handle(s, token);

        for (int i = 1; i <= s->sp; i++)
        {
            printf("%d", s->stack[i]);
        }
        printf("\n");
    }

    return 0;
}