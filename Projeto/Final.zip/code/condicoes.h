/**
 * @file condições.h
 * @brief Header file que contém a declaração das funções de operação condicional usadas em outros modúlos.
 */
int conditionalHandle(STACK *s, char *token);