/**
 * @file operators.h
 * @brief Header file que contém a declaração das funções de operações usadas em outros módulos.
 */

int masterHandle(STACK *s, char *token, char **line);