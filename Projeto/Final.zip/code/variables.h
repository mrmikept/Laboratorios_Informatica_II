/**
 * @file variables.h
 * @brief Header file que contém a declaração das funções de manuseamento de variaveis usadas em outros modúlos.
 */
STACK_ELEM *varValues();
int varHandle(STACK *s, char *token);