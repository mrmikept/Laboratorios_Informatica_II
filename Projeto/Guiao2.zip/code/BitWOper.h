/**
 * @file BitWOper.h
 * @brief Header file que contém a declaração das funções de operações bitwise.
 */
int andBitW(STACK *s, char *token);
int orBitW(STACK *s, char *token);
int xorBitW(STACK *s, char *token);
int notBitW(STACK *s, char *token);
int bitWiseHandle(STACK *s, char *token);
