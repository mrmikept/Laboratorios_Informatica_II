#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "stack.h"

// Função que verifica se o tipo da string token é INT, DOUBLE ou STRING
int tokenTypeIDS(char *token)
{
    int flag = -1; // 0 = CHAR, 1 = INT, 2 = DBL, 3 = STR.
    for (int i = 0; token[i] && token[i] != '\0'; i++)
    {
        if (token[i] < '0' || token[i] > '9') // string double(ponto)
        {
            if (flag == INT && token[i] == '.' && token[i + 1])
            {
                flag = DBL;
            }
            else if (token[0] == '"')
            {
                flag = STR;
            }
        }
        else if (flag == -1)
        {
            flag = INT;
        }
    }
    return flag;
}

// Função que verifica o tipo da string token
int tokenType(char *token, int tokenLength)
{
    if (tokenLength == 1)
    {
        return INT;
    }
    else
    {
        return tokenTypeIDS(token);
    }
}

int convertInt(STACK *s, char *token)
{
    if (strcmp(token, "i") == 0)
    {
        STACK_ELEM stackTOP = pop(s);
        void *intPt = malloc(sizeof(long)); // criar apontador void para uma nova referencia com o tamanho para um long
        if (stackTOP.t == STR)
        {
            sscanf(stackTOP.elem, "%ld", (long *)intPt); // parse de uma string para inteiro
        }
        else if (stackTOP.t == DBL)
        {
            *(long *)intPt = *(double *)stackTOP.elem;
        } else
        {
            *(long *)intPt = *(long *)stackTOP.elem;
        }
        stackTOP.elem = intPt;
        stackTOP.t = INT;
        push(s, stackTOP);
        return 1;
    }
    return 0;
}

int convertChar(STACK *s, char *token)
{
    if (strcmp(token, "c") == 0)
    {
        STACK_ELEM stackTOP = pop(s);
        void *intPt;
        if (stackTOP.t == INT)
        {
            intPt = stackTOP.elem;
        }
        else
        {
            intPt = malloc(sizeof(long));
            sscanf(stackTOP.elem, "%ld", (long *)intPt);
        }
        void *charPt = malloc(sizeof(char));
        *(char *)charPt = (char)(*(long *)intPt);
        stackTOP.elem = charPt;
        stackTOP.t = CHAR;
        push(s, stackTOP);
        return 1;
    }
    return 0;
}

int convertDbl(STACK *s, char *token)
{
    if (strcmp(token, "f") == 0)
    {
        STACK_ELEM stackTOP = pop(s);
        char *str = stackTOP.elem;
        void *doublePt = malloc(sizeof(double));
        if (stackTOP.t == STR)
        {
            *(double *)doublePt = strtod(str, NULL);
        }
        else if (stackTOP.t == INT)
        {
            *(double *)doublePt = *(long *)stackTOP.elem;
        } else
        {
            *(double *)doublePt = *(double *)stackTOP.elem;
        }
        stackTOP.t = DBL;
        stackTOP.elem = doublePt;
        push(s, stackTOP);
        return 1;
    }
    return 0;
}

int convertString(STACK *s, char *token)
{
    if (strcmp(token, "s") == 0)
    {
        STACK_ELEM stackTOP = pop(s);
        if (stackTOP.t == INT)
        {
            char *str = malloc((ceil(log10(*(long *)stackTOP.elem)) + 1) * sizeof(char));
            sprintf(str, "%d", (*(int *)stackTOP.elem));
            stackTOP.t = STR;
            stackTOP.elem = str;
            push(s, stackTOP);
            return 1;
        }
        else if (stackTOP.t == DBL)
        {
        }
    }
    return 0;
}

int parseHandle(STACK *s, char* token)
{
    return(convertInt(s, token) || convertDbl(s, token) || convertChar(s, token) || convertString(s, token));
}