/**
 * @file mathOper.c
 * @brief Ficheiro mathOper.c que contém todas as funções relativas a operações matemáticas.
 */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "stack.h"

/**
 * @brief Função de adição de dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' + ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, é verificado o tipo de x e y de forma a fazer a Type Cast do apontador void de forma correta e com o auxilio da função push coloca no topo da stack o resultado da adição de x com y e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s - Recebe um apontador para a stack.
 * @param[in] token - Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da adição de x e y.
 * @param void *intPt - Apontador void com o tamanho de um long para a soma de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a soma de doubles.
 * @param function push(s, res) - Guarda no topo da stack o resultado da soma de x e y.
 */

int add(STACK *s, char *token)
{
    if (strcmp(token, "+") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)x.elem) + *((long *)y.elem);
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
        else if (x.t == DBL || y.t == DBL)
        {
            STACK_ELEM res;
            void *dblPt = malloc(sizeof(double));
            if (x.t == INT)
            {
                *(double *)dblPt = (*((long *)x.elem)) + (*((double *)y.elem));
            }
            else if (y.t == INT)
            {
                *(double *)dblPt = (*((long *)x.elem)) + (*((long *)y.elem));
            }
            else
            {
                *(double *)dblPt = (*((double *)x.elem)) + (*((double *)y.elem));
            }
            res.elem = dblPt;
            res.t = DBL;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de subtração de dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' - ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, é verificado o tipo de x e y de forma a fazer a Type Cast do apontador void de forma correta e com o auxilio da função push coloca no topo da stack o resultado da subtração de x com y e retorna 1 à função mathHandle.
 *  Se não for igual então retorna 0 à função handle.
 * @param[in] s - Recebe um apontador para a stack.
 * @param[in] token - Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da adição de x e y.
 * @param void *intPt - Apontador void com o tamanho de um long para a subtração de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a subtração de doubles.
 * @param function push(s, res) - Guarda no topo da stack o resultado da subtração de x e y.
 */

int sub(STACK *s, char *token)
{
    if (strcmp(token, "-") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)y.elem) - *((long *)x.elem);
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
        else if (x.t == DBL || y.t == DBL)
        {
            STACK_ELEM res;
            void *dbl = malloc(sizeof(double));
            if (x.t == INT)
            {
                *(double *)dbl = *((double *)y.elem) - *((long *)x.elem);
            }
            else if (y.t == INT)
            {
                *(double *)dbl = *((long *)y.elem) - *((double *)x.elem);
            }
            else
            {
                *(double *)dbl = *((double *)y.elem) - *((double *)x.elem);
            }
            res.elem = dbl;
            res.t = DBL;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de multiplicação de dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' * ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, é verificado o tipo de x e y de forma a fazer a Type Cast do apontador void de forma correta e com o auxilio da função push coloca no topo da stack o resultado da multiplicação de x com y e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s - Recebe um apontador para a stack.
 * @param[in] token - Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da multiplicação de x e y.
 * @param void *intPt - Apontador void com o tamanho de um long para a multiplicação de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a multiplicação de doubles.
 * @param function push(s, res) - Guarda no topo da stack o resultado da multiplicação de x e y.
*/
int mult(STACK *s, char *token)
{
    if (strcmp(token, "*") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)x.elem) * *((long *)y.elem);
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
        else if (x.t == DBL || y.t == DBL)
        {
            STACK_ELEM res;
            void *dblPt = malloc(sizeof(double));
            if (x.t == INT)
            {
                *(double *)dblPt = *((long *)x.elem) * *((double *)y.elem);
            }
            else if (y.t == INT)
            {
                *(double *)dblPt = *((double *)x.elem) * *((long *)y.elem);
            }
            else
            {
                *(double *)dblPt = *((double *)x.elem) * *((double *)y.elem);
            }
            res.elem = dblPt;
            res.t = DBL;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de divisão de dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' / ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, é verificado o tipo de x e y de forma a fazer a Type Cast do apontador void de forma correta e com o auxilio da função push coloca no topo da stack o resultado da multiplicação de x com y e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s - Recebe um apontador para a stack.
 * @param[in] token - Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da divisão de x e y.
 * @param void *intPt - Apontador void com o tamanho de um long para a divisão de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a divisão de doubles.
 * @param function push(s, res) - Guarda no topo da stack o resultado da divisão de y por x.
*/
int divd(STACK *s, char *token)
{
    if (strcmp(token, "/") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)y.elem) / *((long *)x.elem);
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
        else if (x.t == DBL || y.t == DBL)
        {
            STACK_ELEM res;
            void *dbl = malloc(sizeof(double));
            if (x.t == INT)
            {
                *(double *)dbl = *((double *)y.elem) / *((long *)x.elem);
            }
            else if (y.t == INT)
            {
                *(double *)dbl = *((long *)y.elem) / *((double *)x.elem);
            }
            else
            {
                *(double *)dbl = *((double *)y.elem) / *((double *)x.elem);
            }
            res.elem = dbl;
            res.t = DBL;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de decremento do valor do topo da stack
 *
 *  É comparado o token com o caracter ' ( ',
 *  Se for igual então guarda o valor do topo da stack na variavel x, é verificado então o tipo de x de forma a fazer Type Cast correto do apontador void e com o auxilio da função push coloca no topo da stack o resultado da decrementação de x e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o valor do topo da stack com o auxilio da função pop.
 * @param void *intPt - Apontador void com o tamanho de um long para a decrementação de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a decrementação de doubles.
 * @param void *CharPt - Apontador void com o tamanho de um char para a decrementação de char's.
 * @param function push(s, res) - Guarda no topo da stack o resultado da divisão de y por x.
 */
int dec(STACK *s, char *token)
{
    if (strcmp(token, "(") == 0)
    {
        STACK_ELEM x = pop(s);
        if (x.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)x.elem) - 1;
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
        else if (x.t == DBL)
        {
            STACK_ELEM res;
            void *dbl = malloc(sizeof(double));
            *(double *)dbl = *((double *)x.elem) - 1;
            res.elem = dbl;
            res.t = DBL;
            push(s, res);
            return 1;
        }
        else
        {
            STACK_ELEM res;
            void *charPt = malloc(sizeof(char));
            *(char *)charPt = (char)(*(long *)x.elem - 1);
            res.t = CHAR;
            res.elem = charPt;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de incremento do valor do topo da stack
 *
 *  É comparado o token com o caracter ' ( ',
 *  Se for igual então guarda o valor do topo da stack na variavel x, é verificado então o tipo de x de forma a fazer Type Cast correto do apontador void e com o auxilio da função push coloca no topo da stack o resultado da incrementação de x e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o valor do topo da stack com o auxilio da função pop.
 * @param void *intPt - Apontador void com o tamanho de um long para a decrementação de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a decrementação de doubles.
 * @param void *CharPt - Apontador void com o tamanho de um char para a decrementação de char's.
 * @param function push(s, res) - Guarda no topo da stack o resultado da divisão de y por x.
 */
int inc(STACK *s, char *token)
{
    if (strcmp(token, ")") == 0)
    {
        STACK_ELEM x = pop(s);
        if (x.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)x.elem) + 1;
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
        else if (x.t == DBL)
        {
            STACK_ELEM res;
            void *dbl = malloc(sizeof(double));
            *(double *)dbl = *((double *)x.elem) + 1;
            res.elem = dbl;
            res.t = DBL;
            push(s, res);
            return 1;
        }
        else
        {
            STACK_ELEM res;
            void *charPt = malloc(sizeof(char));
            *(char *)charPt = (char)(*(long *)x.elem + 1);
            res.t = CHAR;
            res.elem = charPt;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de operação modulo de dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' % ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, é verificado se o tipo de x e y é inteiro, fazer a Type Cast do apontador void para inteiro e com o auxilio da função push coloca no topo da stack o resultado da operação modulo de x com y e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s - Recebe um apontador para a stack.
 * @param[in] token - Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da operação modulo de x e y.
 * @param void *intPt - Apontador void com o tamanho de um long para a divisão de inteiros.
 * @param function push(s, res) - Guarda no topo da stack o resultado da divisão de y por x.
*/
int modulo(STACK *s, char *token)
{
    if (strcmp(token, "%") == 0)
    {
        STACK_ELEM y = pop(s);
        STACK_ELEM x = pop(s);
        if (x.t == INT && y.t == INT)
        {
            STACK_ELEM res;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = *((long *)x.elem) % *((long *)y.elem);
            res.elem = intPt;
            res.t = INT;
            push(s, res);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de exponenciação de dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' # ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis expon e base, é verificado o tipo de expon e base de forma a fazer a Type Cast do apontador void de forma correta e com o auxilio da função push coloca no topo da stack o resultado da exponenciação de x com y e retorna 1 à função MathHandle.
 *  Se não for igual então retorna 0 à função MathHandle.
 * @param[in] s - Recebe um apontador para a stack.
 * @param[in] token - Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM expon - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM base - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res_elem - Guarda o resultado da exponenciação.
 * @param int res - Guarda o resultado da exponenciação da base pelo expon no caso de serem inteiros.
 * @param double res - Guarda o resultado na exponenciação da base pelo expon no caso de serem doubles.
 * @param void *intPt - Apontador void com o tamanho de um long para a exponenciação de inteiros.
 * @param void *dblPt - Apontador void com o tamanho de um double para a exponenciação de doubles.
 * @param function push(s, res) - Guarda no topo da stack o resultado da exponenciação da base pelo expon.
*/
int expo(STACK *s, char *token)
{
    if (strcmp(token, "#") == 0)
    {
        STACK_ELEM expon = pop(s);
        STACK_ELEM base = pop(s);
        if (expon.t == INT && base.t == INT)
        {
            int res = 1;
            for (int i = 0; i < *((long *)expon.elem); i++)
            {
                res *= *((long *)base.elem);
            }
            STACK_ELEM res_elem;
            void *intPt = malloc(sizeof(int));
            *(long *)intPt = res;
            res_elem.elem = intPt;
            res_elem.t = INT;
            push(s, res_elem);
            return 1;
        }
        else if (expon.t == DBL || base.t == DBL)
        {
            STACK_ELEM res_elem;
            void *dblPt = malloc(sizeof(double));
            double res;
            if (expon.t == INT)
            {
                res = pow(*(double *)base.elem, (double)(*(long *)expon.elem));
            }
            else if (base.t == INT)
            {
                res = pow((double)(*(long *)base.elem), *(double *)expon.elem);
            }
            else
            {
                res = pow(*(double *)base.elem, *(double *)expon.elem);
            }
            *(double *)dblPt = res;
            res_elem.elem = dblPt;
            res_elem.t = DBL;
            push(s, res_elem);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função Math Handle que chama as funções de operações matemáticas.
 *
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se foi executada com êxito.
 * @retval 0 se não foi executada com êxito.
 *
 * @param Function add(s,token) - Função de soma de dois valores do topo da Stack.
 * @param Function sub(s,token) - Função de subtração de dois valores do topo da Stack.
 * @param Function mult(s,token) - Função de multiplicação de dois valores do topo da Stack.
 * @param Function divd(s, token) - Função de divisão de dois valores do topo da Stack.
 * @param Function dec(s, token) - Função de decrementação do valor do topo da Stack.
 * @param Function inc(s, token) - Função de incrementação do valor do topo da Stack.
 * @param Function modulo(s, token) - Função de operação de dois valores do topo da Stack.
 * @param Function expo(s, token) - Função de exponenciação de dois valores do topo da Stack.
 */
int mathHandle(STACK *s, char *token)
{
    return(add(s,token) || sub(s,token) || mult(s,token) || divd(s, token) || dec(s, token) || inc(s, token) || modulo(s, token) || expo(s,token));
}