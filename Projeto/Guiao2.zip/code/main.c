/**
 * @file main.c
 * @brief Ficheiro main.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "stack.h"
#include "parse.h"
#include "mathOper.h"
#include "StackManOper.h"
#include "BitWOper.h"


/**
 * @brief Função Master Handle que chama as restantes funções handle.
 *
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se foi executada com êxito.
 * @retval 0 se não foi executada com êxito.
 *
 * @param Function mathHandle(s, token) - Função handle para as operações matemáticas.
 * @param Function bitWiseHandle(s, token) - Função handle para as operações matemáticas.
 * @param Function parseHandle(s, token) - Função handle para as operações de conversões de tipos.
 * @param Function stackManipHandle(s, token) - Função handle para as operações de manipulação de stack.
 */
int masterHandle(STACK *s, char *token) {
    return (mathHandle(s, token) || bitWiseHandle(s, token) || parseHandle(s, token)|| stackManipHandle(s, token));
}

/**
 * @brief Função main.
 *
 * Primeiro cria uma nova stack e depois recebe uma linha com o stdin e passa os parametros para a função masterHandle. No fim chama printStack.
 *
 * @param Stack *s - Apontador para a Stack Criada.
 * @param char line[BUFSIZ] - String que guarda o conteúdo de uma linha.
 * @param char token[BUFSIZ] - String que guarda o conteudo de um token.
 * @param Function new_Stack() - Função que cria uma nova Stack.
 * @param Function masterHandle(s, token) - Função Master Handle que chama as restantes funções handle.
 * @param Function printStack(s) - Função que faz print do conteudo da Stack.
 */
int main() {
    STACK *s = new_Stack();
    char line[BUFSIZ];
    char token[BUFSIZ];

    if (fgets(line, BUFSIZ, stdin) != NULL)
    {
        while (sscanf(line, "%s%[^\n]", token, line) == 2)
        {
            masterHandle(s, token);
        }
        masterHandle(s, token);
        printStack(s);
    }

    return 0;
}