/**
 * @file BitWOper.h
 * @brief Header file que contém a declaração das funções de operações de manipulação da stack.
 */
int rotateTwo(STACK *s, char *token);
int copyNElem(STACK *s, char *token);
int val(STACK *s, char *token);
int comandoL(STACK *s, char *token);
int ipop(STACK *s, char *token);
int duplicate(STACK *s, char *token);
int rotate(STACK *s, char *token);
int stackManipHandle(STACK *s, char *token);