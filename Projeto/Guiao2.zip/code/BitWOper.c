/**
 * @file BitWOper.c
 * @brief Ficheiro BitWOper.c que contém todas as funções relativas a operações em bitwise.
 */

#include <string.h>
#include <stdlib.h>
#include "stack.h"

/**
 * @brief Função de operação e(bitwise) dos dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' & ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação e(bitwise) de x com y e retorna 1 à função bitWHandle.
 *  Se não for igual então retorna 0 à função bitWHandle.
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da operação e(bitwise).
 * @param void *intPt - Apontador void com o tamanho para um inteiro.
 * @param function push(s, res) - Guarda no topo da stack o resultado da operação e(bitwise) de x com y.
 */

int andBitW(STACK *s, char *token)
{
    if (strcmp(token, "&") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            int res = *((long *)x.elem) & *((long *)y.elem);
            STACK_ELEM res_elem;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = res;
            res_elem.elem = intPt;
            res_elem.t = INT;
            push(s, res_elem);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de operação ou(bitwise) dos dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' | ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação ou(bitwise) de x com y e retorna 1 à função bitWHandle.
 *  Se não for igual então retorna 0 à função bitWHandle.
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da operação ou(bitwise).
 * @param void *intPt - Apontador void com o tamanho para um inteiro.
 * @param function push(s, res) - Guarda no topo da stack o resultado da operação ou(bitwise) de x com y.
 */
int orBitW(STACK *s, char *token)
{
    if (strcmp(token, "|") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            int res = *((long *)x.elem) | *((long *)y.elem);
            STACK_ELEM res_elem;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = res;
            res_elem.elem = intPt;
            res_elem.t = INT;
            push(s, res_elem);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de operação xor(bitwise) dos dois valores do topo da stack.
 *
 *  É comparado o token com o caracter ' ^ ',
 *  Se for igual então guarda os dois valores no topo da stack nas variaveis x e y, com o auxilio da função push coloca no topo da stack o resultado da operação xor(bitwise) de x com y e retorna 1 à função bitWHandle.
 *  Se não for igual então retorna 0 à função bitWHandle.
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM y - Guarda o segundo valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o resultado da operação xor(bitwise).
 * @param void *intPt - Apontador void com o tamanho para um inteiro.
 * @param function push(s, res) - Guarda no topo da stack o resultado da operação xor(bitwise) de x com y.
 */
int xorBitW(STACK *s, char *token)
{
    if (strcmp(token, "^") == 0)
    {
        STACK_ELEM x = pop(s);
        STACK_ELEM y = pop(s);
        if (x.t == INT && y.t == INT)
        {
            long res = (*((long *)x.elem)) ^ (*((long *)y.elem));
            STACK_ELEM res_elem;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = res;
            res_elem.elem = intPt;
            res_elem.t = INT;
            push(s, res_elem);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função de operação not(bitwise) do valor no topo da stack.
 *
 *  É comparado o token com o caracter ' ~ ',
 *  Se for igual então guarda o valor do topo da stack nas variaveis x, com o auxilio da função push coloca no topo da stack o resultado da operação not(bitwise) de x e retorna 1 à função bitWHandle.
 *  Se não for igual então retorna 0 à função bitWHandle.
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se a função foi executada com sucesso.
 * @retval 0 se não foi possivel executar a função.
 * @param STACK_ELEM x - Guarda o primeiro valor do topo da stack com o auxilio da função pop.
 * @param STACK_ELEM res - Guarda o valor da operação not(bitwise) de x.
 * @param void *intPt - Apontador void com o tamanho para um inteiro.
 * @param function push(s, res) - Guarda no topo da stack o resultado da operação not(bitwise) de x.
 */
int notBitW(STACK *s, char *token)
{
    if (strcmp(token, "~") == 0)
    {
        STACK_ELEM x = pop(s);
        if (x.t == INT)
        {
            long res = ~*((long *)x.elem);
            STACK_ELEM res_elem;
            void *intPt = malloc(sizeof(long));
            *(long *)intPt = res;
            res_elem.elem = intPt;
            res_elem.t = INT;
            push(s, res_elem);
            return 1;
        }
    }
    return 0;
}

/**
 * @brief Função BitWise Handle que chama as funções de operações de BitWise.
 *
 * @param[in] s Recebe um apontador para a stack.
 * @param[in] token Recebe um token.
 * @retval 1 se foi executada com êxito.
 * @retval 0 se não foi executada com êxito.
 *
 * @param Function andBitW(s, token) - Função e(Bitwise) de dois valores do topo da stack.
 * @param Function orBitW(s, token) - Função ou(Bitwise) de dois valores do topo da stack.
 * @param Function xorBitW(s, token) - Função xor(Bitwise) de dois valores do topo da stack.
 * @param Function notBitW(s, token) - Função not(Bitwise) do valor do topo da stack.
 */
int bitWiseHandle(STACK *s, char *token)
{
    return (andBitW(s, token) || orBitW(s, token) || xorBitW(s, token) || notBitW(s, token));
}