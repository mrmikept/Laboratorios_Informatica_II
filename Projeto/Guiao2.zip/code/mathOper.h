/**
 * @file mathOper.h
 * @brief Header file que contém a declaração das funções de operações matemáticas.
 */
int add(STACK *s, char* token);
int sub(STACK *s, char* token);
int mult(STACK *s, char* token);
int divd(STACK *s, char *token);
int dec(STACK *s, char* token);
int inc(STACK *s, char* token);
int modulo(STACK *s, char* token);
int expo(STACK *s, char *token);
int mathHandle(STACK *s, char *token);